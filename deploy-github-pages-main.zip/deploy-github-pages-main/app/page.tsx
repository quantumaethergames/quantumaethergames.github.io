export default function Home() {
  return (
    <main>
      <div>Next.js on GitHub Pages</div>
    </main>
  );
}
